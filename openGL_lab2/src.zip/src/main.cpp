#include <iostream>
#include "MyEngine.h"

#define use(ns) using ns;
use(std::cout) use(std::endl)

int main() {
	MyEngine engine;

	return 0;
}